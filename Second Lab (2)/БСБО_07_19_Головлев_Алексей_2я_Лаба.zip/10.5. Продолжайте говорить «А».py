# Алексей Головлев, группа БСБО-07-19

while input()[0].upper() == "А": continue
