# Алексей Головлев, группа БСБО-07-19

text = input()
while len(text) >= 2:
    text = text[1: -1]
    print(text)