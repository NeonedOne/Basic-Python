# Алексей Головлев, группа БСБО-07-19

text = input()
if text[0].upper() == "А":
    print("ДА")
else:
    print("НЕТ")