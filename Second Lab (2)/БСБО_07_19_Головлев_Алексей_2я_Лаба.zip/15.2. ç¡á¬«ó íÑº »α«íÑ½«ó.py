# Алексей Головлев, группа БСБО-07-19

print(len(input().replace(" ", "").replace("	", "")))